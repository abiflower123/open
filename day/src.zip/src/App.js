
import React from "react";
import RecipeSearch from "./components/RecipeSearch";
import "./style.css"; // ✅ Ensure this is correctly imported

const App = () => {
    return (
        <div className="app-container">
            
            <RecipeSearch />
        </div>
    );
};

export default App;