import React, { useState } from "react";

const Filters = ({ setFilters }) => {
    const [cuisine, setCuisine] = useState("");
    const [maxTime, setMaxTime] = useState("");

    const applyFilters = () => {
        setFilters({ cuisine, maxReadyTime: maxTime });
    };

    return (
        <div>
            <div class="filters">
                          <select value={cuisine} onChange={(e) => setCuisine(e.target.value)}>
                <option value="">Select Cuisine</option>
                <option value="indian">Indian</option>
                <option value="italian">Italian</option>
                <option value="chinese">Chinese</option>
                <option value="mexican">Mexican</option>
            </select>
            
            <input type="number" placeholder="Max Cooking Time(min)" onChange={(e) => setMaxTime(e.target.value)} />
            
            <button onClick={applyFilters}>Apply Filters</button>
            </div>
        </div>
    );
};

export default Filters;
