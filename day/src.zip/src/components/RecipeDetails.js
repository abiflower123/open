
import React, { useState } from "react";
import VoiceAssistant from "./VoiceAssistant";

const RecipeDetails = ({ recipe }) => {
    const [showInstructions, setShowInstructions] = useState(false);

    // Function to toggle instructions
    const handleViewRecipe = () => {
        setShowInstructions(!showInstructions);
    };

    return (
        <div className="recipe-container">
            <div className="recipe-card">
                <img src={recipe.image} alt={recipe.title} width="200px" />
                <div className="recipe-details">
                    <h3>{recipe.title}</h3>
                    <p>Cooking Time: {recipe.readyInMinutes} mins</p>
                    <p>Ingredients:</p>
                    <ul>
                        {recipe.extendedIngredients.map((ingredient) => (
                            <li key={ingredient.id}>{ingredient.original}</li>
                        ))}
                    </ul>
                    {/* ✅ Fixed: Recipe is now passed correctly to ViewRecipe */}
                    <button onClick={handleViewRecipe} className="read-more">
                        {showInstructions ? "Hide Instructions" : "View Recipe"}
                    </button>
                    
                    {showInstructions && <ViewRecipe recipe={recipe} />}
                </div>
            </div>
        </div>
    );
};

// ✅ Fixed: Now, ViewRecipe receives recipe properly
const ViewRecipe = ({ recipe }) => {
    return (
        <div>
            <h4>Instructions:</h4>
            <p>{recipe.instructions ? recipe.instructions : "No instructions provided."}</p>
            <VoiceAssistant text={recipe.instructions || "No instructions available"} /> 
        </div>
    );
};

export default RecipeDetails;