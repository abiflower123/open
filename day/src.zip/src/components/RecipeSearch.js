
import React, { useState } from "react";
import { fetchRecipes } from "../api";
import Filters from "./Filters";
import RecipeList from "./RecipeList";

const RecipeSearch = () => {
    const [ingredients, setIngredients] = useState("");
    const [filters, setFilters] = useState({});
    const [recipes, setRecipes] = useState([]);

    const handleSearch = async () => {
        const result = await fetchRecipes(ingredients, filters);
        setRecipes(result);
    };

    return (
        <div>
            <header>Smart Recipe Generator</header>
            <div class="search-container">
                          <input
                type="text"
                placeholder="Enter ingredients (comma separated)"
                value={ingredients}
                onChange={(e) => setIngredients(e.target.value)}

            />
            <button onClick={handleSearch} id="s">Search Recipes</button>
            </div>
  
            <Filters setFilters={setFilters} />
            
            <RecipeList recipes={recipes} />
        </div>
    );
};

export default RecipeSearch;